# Content licence

Unless a third-party source is identified, the manuscript text and original figures in this artifact are prepared for release under Creative Commons Attribution 4.0 International (CC BY 4.0).

The author should confirm this licence choice before public deposit. Official OFAC source files remain subject to the terms and public-use conditions of the U.S. Department of the Treasury and are not relicensed by this package.
