# Composable Assurance for Sovereign Digital Currency - v7

This reproducibility package supports the manuscript:

**Composable Assurance for Sovereign Digital Currency: Privacy, financial integrity, adaptive policy and national-scale qualification across independent sovereign ledgers**

## Evidence boundary

The package reports formal-model, synthetic-benchmark, laboratory-prototype and queueing-digital-twin evidence. It does not claim a national CBDC deployment, production-certified cryptography, operational FATF effectiveness or a universal monetary-policy limit.

## Main files

- `output/Composable_Assurance_CBDC_National_Qualification_Manuscript_v7.docx`
- `output/Composable_Assurance_CBDC_National_Qualification_Manuscript_v7.pdf`
- `scripts/` - experiment, figure, manuscript and verification source
- `results/` - machine-readable result tables and summaries
- `figures/` - manuscript diagrams and charts
- `data/` - archived OFAC inputs used by the sanctions benchmark
- `docs/INDEPENDENT_SCORE_AND_KILLER_QUESTIONS_V7.md`
- `docs/VERIFICATION_V7.json`
- `docs/a11y_audit_v7.json`

## Reproduction

Create a Python environment and install `requirements.txt`, then run:

```bash
./RUN_ALL.sh
./VERIFY.sh
```

The sanctions pipeline first generates the entity-disjoint scored benchmark through `sanctions_v6.py`, then calibrates the v7 policy frontier through `sanctions_v7.py`.

## Required external gates

National deployment claims require physical multi-region execution, certified HSMs, realistic PIP workloads, independent security and legal audits, governed real-data privacy/AML studies, live multilingual sanctions adjudication, jurisdiction-specific economic estimation and controlled pilots.
