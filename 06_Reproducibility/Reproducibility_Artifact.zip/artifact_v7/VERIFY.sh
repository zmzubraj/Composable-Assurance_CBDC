#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [[ -f SHA256SUMS ]]; then sha256sum -c SHA256SUMS; fi
python scripts/verify_v7.py
