from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
BLUE='#1f4e79'; MID='#5b9bd5'; PALE='#eaf2f8'; GREEN='#70ad47'; PG='#e2f0d9'; ORANGE='#ed7d31'; PO='#fce4d6'; GRAY='#5b6573'; LG='#f2f4f7'; RED='#c00000'; WHITE='white'; DARK='#222222'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})

def setup(w=11,h=5.8):
    fig,ax=plt.subplots(figsize=(w,h),dpi=220); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off'); return fig,ax

def box(ax,x,y,w,h,text,fc=PALE,ec=BLUE,lw=1.6,fs=10,bold=False,textcolor=DARK):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.018',facecolor=fc,edgecolor=ec,linewidth=lw)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,fontweight='bold' if bold else 'normal',color=textcolor,wrap=True)
    return p

def arrow(ax,x1,y1,x2,y2,label=None,color=GRAY,rad=0):
    a=FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=12,linewidth=1.25,color=color,connectionstyle=f'arc3,rad={rad}')
    ax.add_patch(a)
    if label: ax.text((x1+x2)/2,(y1+y2)/2+0.025,label,ha='center',va='bottom',fontsize=8.3,color=color)

# 1 composable assurance
fig,ax=setup(11,5.5)
box(ax,.03,.74,.94,.16,'COMPOSABLE ASSURANCE OBJECTIVE\nNo property is accepted in isolation; each claim must survive conflicts with the others.',BLUE,BLUE,fs=11.5,bold=True,textcolor=WHITE)
labels=[('Monetary correctness','Supply, reserves, finality'),('Privacy','Linkability and lawful access'),('Financial integrity','AML/CFT and sanctions'),('Policy stability','Adoption, runs and inclusion'),('Operational resilience','Scale, recovery and cyber')]
xs=[.03,.225,.42,.615,.81]
for (title,sub),x in zip(labels,xs): box(ax,x,.42,.16,.19,title+'\n'+sub,fc=PALE,fs=9.2,bold=True)
for x in xs: arrow(ax,x+.08,.42,x+.08,.29)
box(ax,.08,.10,.84,.15,'EVIDENCE LADDER  |  formal model -> synthetic benchmark -> prototype -> physical qualification -> governed pilot',fc=PG,ec=GREEN,fs=10.5,bold=True)
ax.text(.5,.02,'A deployment claim is permitted only at the highest evidence level actually completed.',ha='center',fontsize=9.2,color=GRAY)
fig.tight_layout(); fig.savefig(OUT/'v7_assurance_stack.png',bbox_inches='tight'); plt.close(fig)

# 2 architecture
fig,ax=setup(12,6.2)
box(ax,.03,.72,.18,.18,'Central bank\nmonetary core\nreserves | CBDC | audit',fc=PG,ec=GREEN,fs=10,bold=True)
box(ax,.28,.72,.18,.18,'Regulated PIPs\nwallets | KYC | fraud\ncustomer support',fc=PALE,fs=10,bold=True)
box(ax,.53,.72,.18,.18,'Identity & privacy\ncredentials | vaults\nselective disclosure',fc=PALE,fs=10,bold=True)
box(ax,.78,.72,.18,.18,'Financial integrity\nrules | analytics\ncase management',fc=PO,ec=ORANGE,fs=10,bold=True)
for i in range(3): arrow(ax,[.21,.46,.71][i],.81,[.28,.53,.78][i],.81)
box(ax,.10,.39,.34,.17,'Domestic deterministic ledger A\nreserve-settled issuance | conversion | escrow | finality',fc=LG,ec=BLUE,fs=10,bold=True)
box(ax,.56,.39,.34,.17,'Domestic deterministic ledger B\nreserve-settled issuance | conversion | escrow | finality',fc=LG,ec=BLUE,fs=10,bold=True)
box(ax,.35,.13,.30,.15,'Cross-border evidence service\nquotes | compliance proofs | prepare receipts\nPREPARE and COMMIT/ABORT certificates',fc=PO,ec=ORANGE,fs=9.5,bold=True)
arrow(ax,.27,.39,.40,.28,'signed evidence',BLUE); arrow(ax,.73,.39,.60,.28,'signed evidence',BLUE)
arrow(ax,.40,.13,.27,.39,'terminal certificate',GREEN); arrow(ax,.60,.13,.73,.39,'terminal certificate',GREEN)
ax.text(.5,.04,'No wrapped CBDC, no foreign minting, no common global monetary ledger.',ha='center',fontsize=10,color=RED,fontweight='bold')
fig.tight_layout(); fig.savefig(OUT/'v7_architecture.png',bbox_inches='tight'); plt.close(fig)

# 3 cross border
fig,ax=setup(12,6.3)
cols=[.06,.29,.52,.75]; names=['PIP / Ledger A','Decision quorum','PIP / Ledger B','Recovery & audit']
for x,n in zip(cols,names): box(ax,x,.87,.17,.08,n,fc=BLUE,ec=BLUE,fs=9.3,bold=True,textcolor=WHITE)
ys=[.76,.63,.50,.37,.24,.11]
steps=[('1. Lock amount A; emit PA','1. Validate PI, Q, CA, CB','1. Lock amount B; emit PB','Evidence is versioned'),('2. Send PA','2. Verify both receipts','2. Send PB','Reject stale/mismatch'),('3. Await PC','3. Issue 5-of-7 PREPARE','3. Await PC','No local-timeout abort'),('4. Receive terminal TC','4. Issue COMMIT or ABORT','4. Receive terminal TC','One decision per tx'),('5. Idempotent finalize','5. Publish certificate log','5. Idempotent finalize','Recover after restart'),('6. Reconcile balances','6. Audit quorum evidence','6. Reconcile balances','Legal evidence retained')]
for y,row in zip(ys,steps):
    for x,txt in zip(cols,row): box(ax,x,y,.17,.075,txt,fc=WHITE,ec=MID,lw=1,fs=8.2)
for x in cols:
    for y1,y2 in zip([.87]+[y+.075 for y in ys[:-1]],[y+.075 for y in ys]): arrow(ax,x+.085,y1,x+.085,y2,color=GRAY)
arrow(ax,.23,.675,.52,.675,'prepare evidence',ORANGE); arrow(ax,.69,.545,.29,.545,'PREPARE certificate',GREEN); arrow(ax,.46,.285,.75,.285,'terminal certificate',GREEN)
fig.tight_layout(); fig.savefig(OUT/'v7_cross_border_sequence.png',bbox_inches='tight'); plt.close(fig)

# 4 privacy + DP
fig,ax=setup(12,6.2)
box(ax,.03,.70,.20,.20,'Customer identity\nfull KYC and recovery\nheld by responsible PIP',fc=PO,ec=ORANGE,fs=10,bold=True)
box(ax,.29,.70,.20,.20,'Rotating ledger view\npseudonyms | amount | state\nminimum settlement metadata',fc=PALE,fs=10,bold=True)
box(ax,.55,.70,.20,.20,'Compliance proof\ntransaction-bound predicate\nno stable presentation ID',fc=PG,ec=GREEN,fs=10,bold=True)
box(ax,.81,.70,.16,.20,'Threshold disclosure\nlegal basis + quorum\nimmutable access log',fc=LG,fs=9.5,bold=True)
arrow(ax,.23,.80,.29,.80); arrow(ax,.49,.80,.55,.80); arrow(ax,.75,.80,.81,.80)
box(ax,.06,.34,.25,.18,'Learned red-team attackers\nnetwork | merchant coalition\ncompromised PIP | auxiliary data',fc=LG,fs=9.5,bold=True)
box(ax,.38,.34,.25,.18,'Mitigations\nrelay standardization\nshielded batching | timing controls',fc=PG,ec=GREEN,fs=9.5,bold=True)
box(ax,.70,.34,.24,.18,'Measured residual risk\nAUC | top-k | MRR | rank\nunseen users + generator shift',fc=PO,ec=ORANGE,fs=9.5,bold=True)
arrow(ax,.31,.43,.38,.43); arrow(ax,.63,.43,.70,.43)
box(ax,.17,.08,.66,.14,'Registered public statistics: person-level add/remove adjacency -> contribution bound 3\nLaplace mechanism -> 12-release privacy accountant',fc=BLUE,ec=BLUE,fs=9.5,bold=True,textcolor=WHITE)
fig.tight_layout(); fig.savefig(OUT/'v7_privacy_dp_pipeline.png',bbox_inches='tight'); plt.close(fig)

# 5 AML
fig,ax=setup(12,6.2)
fams=[('Profile mix',.04),('Calendar / payroll',.27),('Merchant network',.50),('Remittance corridor',.73)]
for n,x in fams: box(ax,x,.75,.19,.13,n+'\n4 independent graphs',fc=PALE,fs=9.4,bold=True)
for x in [.135,.365,.595,.825]: arrow(ax,x,.75,x,.62)
box(ax,.08,.47,.35,.14,'PIP-local baseline\nfeatures restricted to institution-visible transactions',fc=LG,fs=9.5,bold=True)
box(ax,.57,.47,.35,.14,'Minimized cross-PIP network view\ngraph features recomputed inside each split',fc=PG,ec=GREEN,fs=9.5,bold=True)
for x in [.365,.595]: arrow(ax,x,.47,.49,.35)
box(ax,.29,.22,.42,.13,'Paired graph-level inference\ndelta_i = AP_network,i - AP_local,i\nbootstrap CI + Wilcoxon + sign test + family heterogeneity',fc=PO,ec=ORANGE,fs=9.5,bold=True)
arrow(ax,.50,.22,.50,.12)
box(ax,.15,.02,.70,.10,'Prospective effectiveness gate: investigator time -> SAR/STR quality -> FIU feedback\nrestraint/recovery -> harm/fairness',fc=BLUE,ec=BLUE,fs=9.0,bold=True,textcolor=WHITE)
fig.tight_layout(); fig.savefig(OUT/'v7_aml_evaluation.png',bbox_inches='tight'); plt.close(fig)

# 6 sanctions
fig,ax=setup(12,6.2)
items=[('Versioned official lists','records | aliases | identifiers'),('Candidate retrieval','multilingual | phonetic | token'),('Evidence scoring','name + DOB + POB + address'),('Policy frontier','recall vs workload vs harm'),('Analyst disposition','reason code | escalation | audit'),('Ownership graph','direct + indirect aggregate control')]
xs=[.02,.185,.35,.515,.68,.845]
for (a,b),x in zip(items,xs): box(ax,x,.66,.135,.22,a+'\n'+b,fc=PALE if x<.515 else PO,ec=BLUE if x<.515 else ORANGE,fs=8.5,bold=True)
for x1,x2 in zip(xs[:-1],xs[1:]): arrow(ax,x1+.135,.77,x2,.77)
box(ax,.06,.35,.26,.16,'Calibration split\nselect threshold before test\nreport PR-AUC, Brier and ECE',fc=LG,fs=9.2,bold=True)
box(ax,.37,.35,.26,.16,'Prevalence-adjusted workload\nPPV(pi), false alerts / million\nanalyst-hours / million',fc=PG,ec=GREEN,fs=9.2,bold=True)
box(ax,.68,.35,.26,.16,'Operational gate\nreal customer distribution\nmultilingual adjudication\nlive ownership and legal review',fc=PO,ec=ORANGE,fs=9.2,bold=True)
arrow(ax,.32,.43,.37,.43); arrow(ax,.63,.43,.68,.43)
box(ax,.16,.08,.68,.14,'A screening score ranks possible matches; it is not a legal determination\nof blocking, licensing or ownership.',fc=BLUE,ec=BLUE,fs=9.4,bold=True,textcolor=WHITE)
fig.tight_layout(); fig.savefig(OUT/'v7_sanctions_workflow.png',bbox_inches='tight'); plt.close(fig)

# 7 economic
fig,ax=setup(12,6.2)
box(ax,.04,.72,.20,.17,'Jurisdiction data\nhousehold demand | banks\nstress | distribution',fc=PALE,fs=9.5,bold=True)
box(ax,.30,.72,.20,.17,'Partial identification\nfeasible H, F and r ranges\nunder explicit exposure caps',fc=PG,ec=GREEN,fs=9.5,bold=True)
box(ax,.56,.72,.20,.17,'Robust optimization\nexpected loss + CVaR\nstability | utility | inclusion',fc=PO,ec=ORANGE,fs=9.5,bold=True)
box(ax,.82,.72,.15,.17,'Governed choice\npublish uncertainty\nreview quarterly',fc=LG,fs=9.2,bold=True)
for x1,x2 in [(.24,.30),(.50,.56),(.76,.82)]: arrow(ax,x1,.805,x2,.805)
box(ax,.08,.39,.24,.17,'Normal-state instruments\nholding threshold H\ntiered remuneration r\nautomatic sweep',fc=PALE,fs=9.4,bold=True)
box(ax,.38,.39,.24,.17,'Stress instruments\nflow limit F\nliquidity facilities\ntime-limited emergency rule',fc=PO,ec=ORANGE,fs=9.4,bold=True)
box(ax,.68,.39,.24,.17,'Outcome monitoring\ndeposit substitution | funding\npayment utility | subgroup burden',fc=PG,ec=GREEN,fs=9.4,bold=True)
arrow(ax,.32,.475,.38,.475); arrow(ax,.62,.475,.68,.475)
box(ax,.14,.09,.72,.15,'No universal correct limit: the valid output is a jurisdiction-specific feasible set\nplus a transparent update rule.',fc=BLUE,ec=BLUE,fs=9.7,bold=True,textcolor=WHITE)
fig.tight_layout(); fig.savefig(OUT/'v7_economic_decision.png',bbox_inches='tight'); plt.close(fig)

# 8 performance
fig,ax=setup(12,6.2)
stages=[('1. Analytical lower bound','service demand | utilization cap\nheadroom | bottleneck units',.04),('2. Trace-driven digital twin','bursts | queues | region loss\nHSM slowdown | overload control',.28),('3. Physical qualification','3+ regions | certified HSMs\nproduction PIPs | sustained load',.52),('4. Governed pilot','real workload | operations\nindependent audit | exit gate',.76)]
for title,sub,x in stages: box(ax,x,.63,.20,.24,title+'\n'+sub,fc=PALE if x<.52 else PG,ec=BLUE if x<.52 else GREEN,fs=9.2,bold=True)
for x1,x2 in [(.24,.28),(.48,.52),(.72,.76)]: arrow(ax,x1,.75,x2,.75)
box(ax,.06,.33,.25,.15,'Necessary lower bound\nn_j >= ceil(lambda h s_j / rho_max)\ndoes not guarantee hardware sufficiency',fc=LG,fs=9.2,bold=True)
box(ax,.375,.33,.25,.15,'Model falsification\n40k TPS + region loss breaches SLO\nqueues expose unsafe capacity claims',fc=PO,ec=ORANGE,fs=9.2,bold=True)
box(ax,.69,.33,.25,.15,'Acceptance evidence\np99 | availability | RTO/RPO\nno split finality | invariant closure',fc=PG,ec=GREEN,fs=9.2,bold=True)
arrow(ax,.31,.405,.375,.405); arrow(ax,.625,.405,.69,.405)
box(ax,.12,.08,.76,.14,'National-scale performance is demonstrated only after physical multi-region qualification\nand an independently observed pilot - never by a capacity equation alone.',fc=BLUE,ec=BLUE,fs=9.1,bold=True,textcolor=WHITE)
fig.tight_layout(); fig.savefig(OUT/'v7_national_qualification.png',bbox_inches='tight'); plt.close(fig)

print('created v7 diagrams')
