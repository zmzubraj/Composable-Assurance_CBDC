#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python scripts/cross_border_model_v5.py
python scripts/cross_border_bft_v5.py
python scripts/privacy_v7.py
python scripts/aml_v7.py
python scripts/sanctions_v6.py
python scripts/sanctions_v7.py
python scripts/economic_v7.py
python scripts/performance_v7.py
python scripts/make_diagrams_v7.py
python scripts/build_manuscript_v7.py
python scripts/verify_v7.py
